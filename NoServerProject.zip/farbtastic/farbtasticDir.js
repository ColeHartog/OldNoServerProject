angular.module('mainApp')
.directive('farbtasticDir', function(){
    return {
        
        templateUrl: 'ftest2.html',
        restrict: 'E',
        
    }
})